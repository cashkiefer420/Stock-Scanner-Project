import json

# Load the stock list from the local JSON file
file_path = r'C:\Users\Carte\Downloads\company_tickers.json'

# Open and load the JSON data
with open(file_path, 'r') as file:
    stock_list = json.load(file)

# Extract only the tickers from the JSON
tickers = [value['ticker'] for value in stock_list.values() if 'ticker' in value and value['ticker']]

# Function to sanitize tickers before processing
def sanitize_tickers(tickers):
    # Remove empty strings and duplicates
    sanitized_tickers = list(filter(None, tickers))  # Removes any empty strings
    sanitized_tickers = list(set(sanitized_tickers))  # Removes duplicates by converting to a set and back to a list
    return sanitized_tickers

# Function to process tickers in batches of 100
def process_in_batches(tickers, batch_size=100):
    processed_tickers = []
    
    # Process in batches
    for i in range(0, len(tickers), batch_size):
        batch = tickers[i:i + batch_size]
        
        # Here you can perform the processing logic on each batch
        # For this example, we will just append the batch to the processed_tickers list
        processed_tickers.extend(batch)  # Combine batches into the final list

    return processed_tickers

# Sanitize tickers
sanitized_tickers = sanitize_tickers(tickers)

# Process the tickers
processed_tickers = process_in_batches(sanitized_tickers)

# Clear everything in the stock_list (delete all entries)
stock_list.clear()

# Optionally, if you want to keep it empty or add your processed data back, you can do so
# For example, you can overwrite stock_list with the processed_tickers
stock_list['tickers'] = processed_tickers

# Save the processed (empty or sanitized) tickers into a new JSON file
output_path = r'C:\Users\Carte\Downloads\processed_tickers.json'
with open(output_path, 'w') as outfile:
    json.dump(stock_list, outfile, indent=4)

print("Tickers have been sanitized, the original content cleared, and processed successfully.")

