import yfinance as yf
import json
from datetime import datetime, timedelta
import logging
import time
import os
import concurrent.futures

# Set up logging
log_format = '%(asctime)s - %(levelname)s - %(message)s'
logging.basicConfig(level=logging.INFO, format=log_format)
logging.info("Stock data retrieval started")

# Path to your sample tickers JSON file
ticker_file_path = r'C:\Users\Carte\Downloads\sample_tickers.json'

# Function to load tickers from the JSON file
def load_tickers_from_file():
    if os.path.exists(ticker_file_path):
        try:
            with open(ticker_file_path, 'r') as f:
                tickers_data = json.load(f)
                return tickers_data  # Return the list of tickers directly
        except Exception as e:
            logging.error(f"Error loading tickers from file: {e}")
            return []
    else:
        logging.error(f"File not found: {ticker_file_path}")
        return []

# Function to get the date of the last Monday
def get_last_monday():
    today = datetime.today()
    days_since_monday = today.weekday()  # Monday is 0, Sunday is 6
    if days_since_monday == 0:
        return today  # Today is Monday
    else:
        return today - timedelta(days=days_since_monday)

# Helper function to round to 4 decimal places, return 'N/A' if the value is 'N/A'
def round_value(value):
    try:
        return round(value, 4) if value != 'N/A' else 'N/A'
    except TypeError:
        return 'N/A'

# Function to fetch stock data
def fetch_price(ticker):
    try:
        stock = yf.Ticker(ticker)
        info = stock.history(period="1d")
        
        if len(info) == 0:
            return {'Ticker': ticker, 'Current Price': 'N/A'}

        # Current Price
        current_price = round_value(info['Close'].iloc[-1] if len(info) > 0 else 'N/A')
        
        # Previous Open, Previous Close
        prev_open = round_value(info['Open'].iloc[0] if len(info) > 0 else 'N/A')
        prev_close = round_value(info['Close'].iloc[-2] if len(info) > 1 else 'N/A')

        # Volume Today
        volume_today = round_value(info['Volume'].iloc[-1] if len(info) > 0 else 'N/A')
        
        # Average Volume
        avg_volume = round_value(stock.info.get('averageVolume', 'N/A'))
        
        # Market Cap and Shares Available
        market_cap = round_value(stock.info.get('marketCap', 'N/A'))
        shares_available = round_value(stock.info.get('sharesOutstanding', 'N/A'))
        
        # 3-Month Volume
        three_month_data = stock.history(period="3mo")
        three_month_volume = round_value(three_month_data['Volume'].sum() if len(three_month_data) > 0 else 'N/A')
        
        # Percent Gain Today
        percent_gain_today = round_value(((current_price - prev_close) / prev_close) * 100 if prev_close != 'N/A' else 'N/A')

        # Percent Gain This Week
        percent_gain_this_week = 'N/A'
        last_monday = get_last_monday()
        week_data = stock.history(start=last_monday, end=datetime.now(), period="5d")  # 5 days period
        if len(week_data) > 0:
            price_last_monday = week_data['Close'].iloc[0]
            percent_gain_this_week = round_value(((current_price - price_last_monday) / price_last_monday) * 100)

        # Percent Gain This Month
        percent_gain_this_month = 'N/A'
        first_of_month = datetime(datetime.now().year, datetime.now().month, 1)  # First day of the current month
        month_data = stock.history(period="1mo")  # 1 month period
        if len(month_data) > 0:
            price_start_of_month = month_data['Close'].iloc[0]
            percent_gain_this_month = round_value(((current_price - price_start_of_month) / price_start_of_month) * 100)

        # Percent Gain This Year
        percent_gain_this_year = 'N/A'
        start_of_year = datetime(datetime.now().year, 1, 1)  # January 1st of this year
        year_data = stock.history(start=start_of_year, end=datetime.now())
        if len(year_data) > 0:
            price_start_of_year = year_data['Close'].iloc[0]
            percent_gain_this_year = round_value(((current_price - price_start_of_year) / price_start_of_year) * 100)

        # Return all the stock data, excluding "Percent Gain All Time"
        return {
            'Ticker': ticker,
            'Current Price': current_price,
            'Previous Open': prev_open,
            'Previous Close': prev_close,
            'Volume Today': volume_today,
            'Average Volume': avg_volume,
            'Market Cap': market_cap,
            'Shares Available': shares_available,
            '3-Month Volume': three_month_volume,
            'Percent Gain Today': percent_gain_today,
            'Percent Gain This Week': percent_gain_this_week,
            'Percent Gain This Month': percent_gain_this_month,
            'Percent Gain This Year': percent_gain_this_year
        }
    except Exception as e:
        logging.error(f"Error fetching data for {ticker}: {e}")
        return { 
            'Ticker': ticker, 
            'Current Price': 'N/A',
            'Previous Open': 'N/A',
            'Previous Close': 'N/A',
            'Volume Today': 'N/A',
            'Average Volume': 'N/A',
            'Market Cap': 'N/A',
            'Shares Available': 'N/A',
            '3-Month Volume': 'N/A',
            'Percent Gain Today': 'N/A',
            'Percent Gain This Week': 'N/A',
            'Percent Gain This Month': 'N/A',
            'Percent Gain This Year': 'N/A'
        }

# Function to fetch and export all stock data to JSON
def export_all_stock_data():
    result = []

    # Load tickers from the file
    stock_list = load_tickers_from_file()

    # If no tickers are loaded, return without doing anything
    if not stock_list:
        logging.error("No tickers found to process.")
        return

    # Fetch new data for each ticker concurrently to improve performance
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(fetch_price, ticker) for ticker in stock_list]
        for future in concurrent.futures.as_completed(futures):
            stock_data = future.result()
            result.append(stock_data)

    # Overwrite the JSON file with the new data
    try:
        with open('stock_data_export.json', 'w') as json_file:
            # Serialize data and handle any non-serializable values
            json.dump(result, json_file, indent=4, default=str)
        logging.info("Stock data exported to stock_data_export.json")
    except Exception as e:
        logging.error(f"Error exporting stock data: {e}")

if __name__ == '__main__':
    while True:
        export_all_stock_data()
        logging.info("Waiting for the next cycle (3 minutes)...")
        time.sleep(180)  # Sleep for 180 seconds (3 minutes)
